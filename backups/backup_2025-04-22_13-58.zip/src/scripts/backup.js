import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

// Para obter o __dirname em ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Verificar se o módulo archiver está instalado e instalá-lo se necessário
try {
  await import('archiver');
} catch (e) {
  console.log('Instalando dependência necessária: archiver...');
  execSync('npm install archiver --save-dev');
  console.log('Instalação concluída.');
}

// Importar archiver após garantir que está instalado
const archiver = (await import('archiver')).default;

// Data atual para o nome do arquivo de backup
const date = new Date();
const timestamp = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}_${String(date.getHours()).padStart(2, '0')}-${String(date.getMinutes()).padStart(2, '0')}`;
const backupFileName = `backup_${timestamp}.zip`;

// Diretório onde o backup será salvo
const backupDir = path.join(__dirname, '../../backups');

// Cria o diretório de backup se não existir
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

const output = fs.createWriteStream(path.join(backupDir, backupFileName));
const archive = archiver('zip', {
  zlib: { level: 9 } // Nível de compressão máximo
});

// Eventos do processo de compressão
output.on('close', () => {
  console.log(`✅ Backup concluído: ${backupFileName}`);
  console.log(`📁 Tamanho total: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`);
  console.log(`📂 Local: ${path.join(backupDir, backupFileName)}`);
});

archive.on('warning', (err) => {
  if (err.code === 'ENOENT') {
    console.warn('⚠️ Aviso:', err);
  } else {
    throw err;
  }
});

archive.on('error', (err) => {
  throw err;
});

// Inicia o arquivo de saída
archive.pipe(output);

// Lista de diretórios e arquivos a serem excluídos do backup
const excludeDirs = [
  'node_modules',
  'dist',
  '.git',
  '.temp',
  'backups'
];

console.log('🔄 Iniciando backup do projeto...');

// Adiciona todos os arquivos do projeto, exceto os excluídos
archive.glob('**/*', {
  cwd: path.join(__dirname, '../..'),
  ignore: excludeDirs.map(dir => `${dir}/**`),
  dot: true // Inclui arquivos que começam com ponto (.)
});

// Finaliza o arquivo
await archive.finalize(); 